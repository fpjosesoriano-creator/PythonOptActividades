"""
Ejercicio 9
Escribe un programa que solicite un texto y que escriba el texto en mayúsculas, en minúsculas,  
con la primera letra en mayúscula, y con la primera letra de cada palabra en mayúscula.
"""
texto=str(input('Proporcioname un texto'))
print(texto.upper())
print(texto.lower())
print(texto.capitalize())
print(texto.title())
