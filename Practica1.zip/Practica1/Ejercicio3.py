"""
Crea un programa que pida tres números por teclado. El programa imprime en consola la media aritmética de los números introducidos
"""
num1=input('Proporciona numero 1: ')
num2=input('Proporciona numero 2: ')
num3=input('Proporciona numero 3: ')

print(f"La media arimética de los 3 nímeros es: {((int(num1)+int(num2)+int(num3))/3)}")