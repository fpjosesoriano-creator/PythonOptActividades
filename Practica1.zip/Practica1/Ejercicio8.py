"""
Ejercicio 8
Escribe un programa que solicite al usuario dos palabras, las cuales se guardarán en dos variables distintas. 
A continuación, almacena en otra variable la concatenación de la primera palabra, más un espacio, más la segunda palabra. Muestra este resultado en pantalla.
"""
palabra1,palabra2=str(input('Dame la primera palabra: ')),str(input('Dame la segunda palabra: '))
print(f"{palabra1} {palabra2}")