"""
Ejercicio 2: Tipo de una variable
Crea una función que reciba una variable y nos diga cuál es su tipo.
"""

def variable_tipo(param):
    return type(param)

#prueba="hola"
#print(variable_tipo(prueba))
print(variable_tipo(1))